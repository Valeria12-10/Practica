﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ТЕРМИНАЛСОТРУДНИКА
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            using (var db = new ХранительПРО_PoglazovaEntities()) // Подключение к базе данных
            {


               var userPersonal = db.Сотрудники.FirstOrDefault(use => use.ID_сотрудника.ToString() == cod.Text);
                if (userPersonal != null)
                {
                    Просмотр_заявок fn = new Просмотр_заявок();
                    fn.Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Неверно введен логин или пароль");
                }
            };
        }
       
    }
}
