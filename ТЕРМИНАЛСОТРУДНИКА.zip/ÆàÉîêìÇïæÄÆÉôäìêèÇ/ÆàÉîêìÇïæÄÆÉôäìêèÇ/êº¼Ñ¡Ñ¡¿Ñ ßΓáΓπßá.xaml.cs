﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace ТЕРМИНАЛСОТРУДНИКА
{
    public partial class Изменение_статуса : Window
    {
        private readonly ХранительПРО_PoglazovaEntities _context;
        public Изменение_статуса()
        { 
            InitializeComponent();
            _context = new ХранительПРО_PoglazovaEntities();
            LoadOrderCodes();
            LoadStatuses();
            SetSelectedStatus();
        }
        private void LoadOrderCodes()
        {
            comom.ItemsSource = _context.Заявка.Select(o => o.ID_Заявки).ToList();
        }

        private void LoadStatuses()
        {
            com.ItemsSource = new string[] { "Отказано", "Одобрено" };
        }
        private void SetSelectedStatus()
        {
            // Получение текущего статуса заявки 
            string selectedStatusString = "Отказано"; 

            // Установка выбранного статуса в ComboBox
            comom.SelectedItem = selectedStatusString;
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(comom.SelectedItem.ToString(), out int code))
            {
                var newStatusString = com.SelectedItem as string;

                var order = _context.Заявка.Include("Статус_заявки").FirstOrDefault(o => o.ID_Заявки == code);
                var newStatus = _context.Статус_заявки.FirstOrDefault(s => s.Название == newStatusString);

                if (order != null && newStatus != null)
                {
                    order.Статус_заявки = newStatus;
                    _context.SaveChanges();
                    MessageBox.Show("Статус заявки успешно обновлен.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    MessageBox.Show("Заявка с указанным кодом не найдена или выбран некорректный статус.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Выберите корректный код заявки.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    

        private void comom_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
