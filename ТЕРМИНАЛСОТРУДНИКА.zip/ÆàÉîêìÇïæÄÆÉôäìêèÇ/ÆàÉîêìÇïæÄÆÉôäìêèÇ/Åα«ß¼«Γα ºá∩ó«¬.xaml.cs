﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;

namespace ТЕРМИНАЛСОТРУДНИКА
{

    public partial class Просмотр_заявок : Window
    {

        public Просмотр_заявок()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            using (var db = new ХранительПРО_PoglazovaEntities())
            {
                var requestsData = (from r in db.Заявка
                                    join st in db.Статус_заявки on r.ID_Статуса equals st.ID_Статуса
                                    select new
                                    {
                                        ID_Заявки = r.ID_Заявки,
                                        Причина_отказа = r.Причина_отказа,
                                        ID_Сотрудника = r.ID_Сотрудника,
                                        Тип_заявки = r.Тип_заявки,
                                        НазваниеСтатуса = st.Название,
                                        
                                      
                                    }).ToList();

                RequestsDataGrid.ItemsSource = requestsData;
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Изменение_статуса fn = new Изменение_статуса();
            fn.Show();
            this.Close();
        }
    }
}
    
