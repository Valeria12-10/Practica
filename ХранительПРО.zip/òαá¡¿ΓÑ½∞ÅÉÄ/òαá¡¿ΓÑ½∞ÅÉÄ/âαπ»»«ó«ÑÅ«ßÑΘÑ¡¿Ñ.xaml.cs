﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ХранительПРО
{
    public partial class ГрупповоеПосещение : Window
    {

        public ГрупповоеПосещение()
        {
            InitializeComponent();

            data1.SelectedDate = DateTime.Today.AddDays(1); // Минимально: следующий день от текущей даты
            data1.DisplayDateStart = DateTime.Today.AddDays(1);
            data1.DisplayDateEnd = DateTime.Today.AddDays(15); // Максимально: на 15 дней вперед от текущей даты


            data2.SelectedDate = DateTime.Today.AddDays(1); // Минимально: следующий день от текущей даты
            data2.DisplayDateStart = DateTime.Today.AddDays(1);
            data2.DisplayDateEnd = DateTime.Today.AddDays(15); // Максимально: на 15 дней вперед от текущей даты
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {

            using (var db = new ХранительПРО_PoglazovaEntities())
            {
                var poc = new Посетители();
                poc.Фамилия = familia.Text;
                poc.Имя = ima.Text;
                poc.Отчество = otchectvo.Text;
                poc.Телефон = tel.Text;
                poc.E_mail = email.Text;
                poc.Организация = organi.Text;
                poc.Примечание = prim.Text;
                poc.Дата_рождения = data3.SelectedDate;
                poc.Серия = seria.Text;
                poc.Номер = nomer.Text;

                var poc1 = db.Посетители.FirstOrDefault(p => p.Фамилия == familia.Text);

                if (poc1 == null)
                {
                    db.Посетители.Add(poc);
                    db.SaveChanges();
                    MessageBox.Show("Посетитель добавлен");
                }

                else { MessageBox.Show("Такой посетитель уже добавлен"); };
            }
        }

        private void newArrange_Click(object sender, RoutedEventArgs e)
        {
            // Проверка наличия обязательных полей
            if (
                data1.SelectedDate == null ||
                data2.SelectedDate == null ||
                zel.SelectedItem == null ||
                podra.SelectedItem == null ||
                fio.SelectedItem == null ||
                string.IsNullOrWhiteSpace(familia.Text) ||
                string.IsNullOrWhiteSpace(ima.Text) ||
                string.IsNullOrWhiteSpace(otchectvo.Text))
            {
                MessageBox.Show("Пожалуйста, заполните обязательные поля: Срок действия заявки,Цель посещения,Подразделение,ФИО, Фамилия, Имя, Отчество");
                return;
            }

            using (var db = new ХранительПРО_PoglazovaEntities())
            {
                //var pro = new Пропуск();
                // pro.Желаемый_срока_начала_заявки = data1.SelectedDate.Value.Date;
                //pro.Желаемый_срока_окончания_заявки = data.SelectedDate.Value.Date;
                //pro.Цель_посещения = zel.SelectedItem != null ? zel.SelectedItem.ToString() : null;   
                //db.Пропуск.Add(pro);

                // Проверяем существование пользователя по серии и номеру паспорта
                var poc = new Посетители();
                poc.Фамилия = familia.Text;
                poc.Имя = ima.Text;
                poc.Отчество = otchectvo.Text;
                poc.Телефон = tel.Text;
                poc.E_mail = email.Text;
                poc.Организация = organi.Text;
                poc.Примечание = prim.Text;
                poc.Дата_рождения = data3.SelectedDate;
                poc.Серия = seria.Text;
                poc.Номер = nomer.Text;

                var poc1 = db.Посетители.FirstOrDefault(p => p.Фамилия == familia.Text);

                if (poc1 == null)
                {
                    db.Посетители.Add(poc);
                    MessageBox.Show("Данные успешно сохранены!");
                }

                else { MessageBox.Show($"Произошла ошибка при сохранении данных"); };

                var gr = new Документы();
                gr.Скан_паспорта_посетителя = LAB.Text;
                db.Документы.Add(gr);
                db.SaveChanges();
            }
        }

        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            // Очистка инф для пропуска
            data2.SelectedDate = null;
            data1.SelectedDate = null;
            zel.SelectedItem = null;

            // Очистка принимающей стороны
            podra.SelectedItem = null;
            fio.SelectedItem = null;
            // Очистка информации о посетителе
            familia.Text = string.Empty;
            ima.Text = string.Empty;
            otchectvo.Text = string.Empty;
            tel.Text = string.Empty;
            email.Text = string.Empty;
            organi.Text = string.Empty;
            prim.Text = string.Empty;
            data3.SelectedDate = null;
            seria.Text = string.Empty;
            nomer.Text = string.Empty;

            // Очистка документов
            LAB.Text = string.Empty;
        }

        private void Attach_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog o = new OpenFileDialog();
            o.Filter = "Все файлы  (*.*)|*.*";
            o.Multiselect = false;

            if (o.ShowDialog() == true)
            {
                string FilePath = o.FileName;

                MessageBox.Show("Файл успешно прикреплен: " + FilePath);
                LAB.Text = FilePath;
            }
            else
            {
                MessageBox.Show("Выбор файла отменен");
            }
        }
    }
}
