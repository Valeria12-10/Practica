﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ХранительПРО
{
    public partial class Регистрация : Window
    {
        public Регистрация()
        {
            InitializeComponent();
        }

        private void Register1_Click(object sender, RoutedEventArgs e)
        {
            using (var db = new ХранительПРО_PoglazovaEntities())
            {
                var existingUserPersonal = db.ПользователиЛичное.Any(uch => uch.ФИО == fio.Text && 
                uch.Номер_телефона== tel.Text && uch.Email== email.Text && uch.Логин == log.Text && 
                uch.Пароль== par.Text);
                var existingUserGroup = db.ПользователиГруппа.Any(uch => uch.ФИО == fio.Text &&
                uch.Номер_телефона == tel.Text && uch.Email == email.Text && uch.Логин == log.Text &&
                uch.Пароль == par.Text);
                if (existingUserPersonal || existingUserGroup)
                {
                    MessageBox.Show("Такой логин уже существует");
                    return;
                }

                var userPersonal = new ПользователиЛичное
                {
                    ФИО = fio.Text,
                    Номер_телефона = tel.Text,
                    Email = email.Text,
                    Логин = log.Text,
                    Пароль = par.Text
                };
                db.ПользователиЛичное.Add(userPersonal);

                if (!string.IsNullOrWhiteSpace(group.Text))
                {
                    // Находим соответствующий ID_Группы по названию группы
                    var groupId = db.Группы.FirstOrDefault(g => g.Название_группы == group.Text)?.ID_Группы;

                    if (groupId != null)
                    {
                        var userGroup = new ПользователиГруппа
                        {
                            ФИО = fio.Text,
                            Номер_телефона = tel.Text,
                            Email = email.Text,
                            Логин = log.Text,
                            Пароль = par.Text,
                            ID_Группы = groupId.Value // Присваиваем ID_Группы
                        };
                        db.ПользователиГруппа.Add(userGroup);
                    }
                    else
                    {
                        MessageBox.Show("Группа не найдена");
                        return;
                    }
                }

                db.SaveChanges();

                MessageBox.Show("Вы успешно зарегистрировались");

                Авторизация fn = new Авторизация();
                fn.Show();
                this.Close();

            }
        }
        private void Group_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
           
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow fn = new MainWindow();
            fn.Show();
            this.Close();
        }
    }
}
