﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.Win32;

namespace ХранительПРО
{
    public partial class ФормаЗаписи : Window
    { 
        

        public ФормаЗаписи()
        {
            InitializeComponent();

            data1.SelectedDate = DateTime.Today.AddDays(1); // Минимально: следующий день от текущей даты
            data1.DisplayDateStart = DateTime.Today.AddDays(1); 
            data1.DisplayDateEnd = DateTime.Today.AddDays(15); // Максимально: на 15 дней вперед от текущей даты

            
            data.SelectedDate = DateTime.Today.AddDays(1); // Минимально: следующий день от текущей даты
            data.DisplayDateStart = DateTime.Today.AddDays(1);
            data.DisplayDateEnd = DateTime.Today.AddDays(15); // Максимально: на 15 дней вперед от текущей даты
        }
    
       

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
        private void Arrange_Click(object sender, RoutedEventArgs e)
        {
            // Проверка наличия обязательных полей
            if (
                data1.SelectedDate == null ||
                data.SelectedDate == null ||
                zel.SelectedItem == null ||
                podra.SelectedItem == null ||
                fio.SelectedItem == null ||
                string.IsNullOrWhiteSpace(familia.Text) ||
                string.IsNullOrWhiteSpace(ima.Text) ||
                string.IsNullOrWhiteSpace(otchectvo.Text))
            {
                MessageBox.Show("Пожалуйста, заполните обязательные поля: Срок действия заявки,Цель посещения,Подразделение,ФИО, Фамилия, Имя, Отчество");
                return;
            }

            using (var db = new ХранительПРО_PoglazovaEntities())
            {
                //var pro = new Пропуск();
                // pro.Желаемый_срока_начала_заявки = data1.SelectedDate.Value.Date;
                //pro.Желаемый_срока_окончания_заявки = data.SelectedDate.Value.Date;
                //pro.Цель_посещения = zel.SelectedItem != null ? zel.SelectedItem.ToString() : null;   
                //db.Пропуск.Add(pro);

                // Проверяем существование пользователя по серии и номеру паспорта
                var poc = new Посетители();
                poc.Фамилия = familia.Text;
                poc.Имя = ima.Text;
                poc.Отчество = otchectvo.Text;
                poc.Телефон = tel.Text;
                poc.E_mail = email.Text;
                poc.Организация = organi.Text;
                poc.Примечание = prim.Text;
                poc.Дата_рождения = data3.SelectedDate;
                poc.Серия = seria.Text;
                poc.Номер = nomer.Text;

                var poc1 = db.Посетители.FirstOrDefault(p => p.Фамилия == familia.Text);

                if (poc1 == null)
                {
                    db.Посетители.Add(poc);      
                    MessageBox.Show("Данные успешно сохранены!");
                }

                else { MessageBox.Show($"Произошла ошибка при сохранении данных"); };

                var gr = new Документы();
                gr.Скан_паспорта_посетителя = LAB1.Text;
                db.Документы.Add(gr);
                db.SaveChanges();
            }
        }
        
                private void Download_Click(object sender, RoutedEventArgs e)
           {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Изображения (*.jpg; *.jpeg; *.png)|*.jpg; *.jpeg; *.png|Все файлы (*.*)|*.*";
            openFileDialog.Multiselect = false; // Разрешить выбирать только один файл

            if (openFileDialog.ShowDialog() == true)
            {
                string imagePath = openFileDialog.FileName;

                try
                {
                    BitmapImage bit = new BitmapImage(new Uri(imagePath));
                    Image1.Source = bit;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка загрузки изображения: " + ex.Message);
                }
            }
        }

        private void ATTACH_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog o = new OpenFileDialog();
            o.Filter = "Все файлы  (*.*)|*.*";
            o.Multiselect = false;

            if (o.ShowDialog() == true)
            {
                string FilePath = o.FileName;

                MessageBox.Show("Файл успешно прикреплен: " + FilePath);
                LAB1.Text = FilePath;
            }
            else
            {
                MessageBox.Show("Выбор файла отменен");
            }

        }

        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            // Очистка инф для пропуска
            data.SelectedDate = null;
            data1.SelectedDate = null;
            zel.SelectedItem = null;

            // Очистка принимающей стороны
            podra.SelectedItem = null;
            fio.SelectedItem = null;
            // Очистка информации о посетителе
            familia.Text = string.Empty;
            ima.Text = string.Empty;
            otchectvo.Text = string.Empty;
            tel.Text = string.Empty;
            email.Text = string.Empty;
            organi.Text = string.Empty;
            prim.Text = string.Empty;
            data3.SelectedDate = null;
            seria.Text = string.Empty;
            nomer.Text = string.Empty;
            Image1 = null;

            // Очистка документов
            LAB1.Text = string.Empty;

        } 
    }
}

